# routes/participant.py
from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from models import db, Room, Question, Participant, Answer
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, HiddenField, TextAreaField # Importe TextAreaField também, caso queira usar o AnswerForm para algo mais tarde
from wtforms.validators import DataRequired, Length, Regexp

participant_bp = Blueprint('participant', __name__)

# --- Formulários WTForms ---
class JoinRoomForm(FlaskForm):
    name = StringField('Seu Nome', validators=[DataRequired(), Length(min=2, max=100)])
    room_code = StringField('Código da Sala (6 dígitos)', validators=[
        DataRequired(),
        Length(min=6, max=6, message='O código deve ter exatamente 6 caracteres.'),
        Regexp(r'^[A-Z0-9]{6}$', message='Código inválido. Use apenas letras maiúsculas e números.')
    ])
    submit = SubmitField('Entrar na Sala')

class AnswerForm(FlaskForm):
    # Campos de resposta serão gerados dinamicamente no template,
    # mas precisamos do formulário para o CSRF token.
    # Podemos adicionar campos aqui se quisermos usar validação WTForms depois.
    submit = SubmitField('Enviar Respostas')


# --- Rotas ---
@participant_bp.route('/join', methods=['GET', 'POST'])
def join_room_route():
    form = JoinRoomForm()
    if form.validate_on_submit():
        room_code = form.room_code.data.upper() # Garante que o código está em maiúsculas
        participant_name = form.name.data

        room = Room.query.filter_by(code=room_code).first()

        if room and room.is_active:
            # Cria ou encontra o participante
            # Simplificação: Assume que nome + room_id é único para a sessão atual.
            # Poderia verificar se já existe um participante com esse nome nesta sala
            # e talvez pedir um nome diferente ou reusar o participante.
            participant = Participant(name=participant_name, room_id=room.id)
            db.session.add(participant)
            db.session.commit() # Salva para obter o ID do participante

            # Guarda informações na sessão do Flask
            session['participant_id'] = participant.id
            session['participant_name'] = participant.name
            session['room_code'] = room.code
            session['room_id'] = room.id # Guarda o ID também

            flash(f'Bem-vindo(a), {participant_name}! Você entrou na sala "{room.name}".', 'success')
            return redirect(url_for('participant.answer_questions_route'))
        elif room and not room.is_active:
             flash('Esta sala não está ativa no momento.', 'warning')
        else:
            flash('Código da sala inválido.', 'danger')

    return render_template('participant/join_room.html', title='Entrar na Sala', form=form)

@participant_bp.route('/questions', methods=['GET', 'POST'])
def answer_questions_route():
    # Verifica se o participante está logado (na sessão)
    if 'participant_id' not in session or 'room_id' not in session:
        flash('Você precisa entrar em uma sala primeiro.', 'warning')
        return redirect(url_for('participant.join_room_route'))

    room_id = session['room_id']
    participant_id = session['participant_id']
    room = Room.query.get_or_404(room_id)
    participant = Participant.query.get_or_404(participant_id)

    # Verifica se a sala ainda está ativa
    if not room.is_active:
        flash('Esta sala foi desativada pelo administrador.', 'danger')
        # Limpa a sessão do participante
        session.pop('participant_id', None)
        session.pop('participant_name', None)
        session.pop('room_code', None)
        session.pop('room_id', None)
        return redirect(url_for('participant.join_room_route'))

    questions = Question.query.filter_by(room_id=room.id).order_by(Question.id).all()

    # Verifica se o participante já respondeu a estas perguntas
    existing_answers = {ans.question_id: ans.text for ans in Answer.query.filter_by(participant_id=participant_id).all()}

    # Crie uma instância do AnswerForm para passar ao template (necessário para o CSRF token)
    form = AnswerForm()

    if request.method == 'POST':
        # Processa as respostas enviadas
        # Como os campos são dinâmicos, validamos manualmente ou confiamos nos dados recebidos
        # Aqui, vamos apenas processar o request.form diretamente, como já está.
        # Se quisesse validar com WTForms, precisaria criar campos dinamicamente no AnswerForm na rota.
        for question in questions:
            answer_text = request.form.get(f'question_{question.id}')
            if answer_text is not None: # Se o campo existe no form
                # Verifica se já existe uma resposta para esta pergunta por este participante
                existing_answer = Answer.query.filter_by(participant_id=participant_id, question_id=question.id).first()
                if existing_answer:
                    # Atualiza a resposta existente
                    existing_answer.text = answer_text
                    existing_answer.submitted_at = db.func.now() # Atualiza timestamp
                elif answer_text.strip(): # Só cria se não estiver vazia
                    # Cria uma nova resposta
                    new_answer = Answer(text=answer_text,
                                        participant_id=participant_id,
                                        question_id=question.id)
                    db.session.add(new_answer)

        try:
            db.session.commit()
            flash('Suas respostas foram salvas com sucesso!', 'success')
            # Recarrega as respostas após salvar para exibir o estado atual
            existing_answers = {ans.question_id: ans.text for ans in Answer.query.filter_by(participant_id=participant_id).all()}

            # Opcional: Redirecionar para uma página de "obrigado" ou limpar sessão
            # session.pop('participant_id', None) ... etc.
            # return redirect(url_for('participant.thank_you'))

        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao salvar respostas: {e}', 'danger')

    # Cria um formulário dinâmico (sem WTForms aqui, direto no HTML) ou passa dados para o template
    return render_template('participant/answer_questions.html',
                           title=f'Perguntas - Sala {room.name}',
                           room=room,
                           questions=questions,
                           participant=participant,
                           existing_answers=existing_answers,
                           form=form) # <--- Adicione esta linha para passar o formulário

# Opcional: Rota de "Obrigado" após submeter
# @participant_bp.route('/thank_you')
# def thank_you():
#    return render_template('participant/thank_you.html', title="Obrigado")