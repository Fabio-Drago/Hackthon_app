# app.py

import datetime
import os
from flask import Flask, render_template, redirect, url_for, flash, request, session
from config import Config

# ### INICIALIZAÇÃO DAS EXTENSÕES (Nível Superior) ###
# Cria as instâncias das extensões sem associá-las a uma app específica ainda.
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager, logout_user, current_user

db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()

# Configurações do Flask-Login (feitas aqui ou dentro da fábrica)
login_manager.login_view = 'participant_auth.login' # Rota para onde redirecionar usuários não logados
login_manager.login_message_category = 'info' # Categoria da mensagem flash para login_required


# ### FUNÇÃO USER_LOADER (Nível Superior) ###
# Esta função é usada pelo Flask-Login para carregar um usuário a partir de um ID de sessão.
from models import Admin # Importe o modelo Admin aqui para o user_loader

@login_manager.user_loader
def load_user(user_id):
    """Carrega um usuário Admin pelo ID para o Flask-Login."""
    if user_id is not None:
        # Usa db.session.get() que é mais robusto para buscar por chave primária
        return db.session.get(Admin, int(user_id))
    return None


# ### FÁBRICA DE APLICAÇÃO ###
def create_app(config_class=Config):
    """Cria e configura a aplicação Flask."""

    app = Flask(__name__)
    app.config.from_object(config_class)

    # Garante que a pasta de instância existe
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass # A pasta já existe

    # ### ASSOCIAÇÃO DAS EXTENSÕES COM A APP (DENTRO DA FÁBRICA) ###
    # Inicializa as extensões associando-as à instância 'app' criada.
    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)

    # ### TORNAR FUNÇÕES PYTHON DISPONÍVEIS NO JINJA2 ###
    # Adiciona a função 'hasattr' aos globals do ambiente Jinja2
    # Isso resolve o erro 'jinja2.exceptions.UndefinedError: 'hasattr' is undefined'
    app.jinja_env.globals['hasattr'] = hasattr


    # ### IMPORTAR MODELOS ###
    # Importe os modelos aqui se precisar que Alembic os descubra via esta fábrica
    # from models import Admin, ParticipantAccount # Deixe comentado se não for estritamente necessário importar aqui


    # ### REGISTRO DE BLUEPRINTS ###
    # Importa e registra os Blueprints que contêm as rotas da aplicação.
    from routes.auth import auth_bp as auth_blueprint
    from routes.admin import admin_bp as admin_blueprint
    from routes.participant import participant_bp as participant_blueprint
    from routes.participant_auth import participant_auth_bp as participant_auth_blueprint
    # from routes.main import main as main_blueprint # Descomente quando criar o blueprint main

    app.register_blueprint(auth_blueprint, url_prefix='/auth') # Rotas de autenticação de admin
    app.register_blueprint(admin_blueprint, url_prefix='/admin') # Rotas da área administrativa
    app.register_blueprint(participant_blueprint, url_prefix='/') # Rotas principais do participante (ex: /join)
    app.register_blueprint(participant_auth_blueprint, url_prefix='/participant') # Rotas de autenticação de participante
    # app.register_blueprint(main_blueprint) # Descomente quando criar o blueprint main para rotas gerais (ex: /)


    # ### CONTEXT PROCESSORS (Opcional) ###
    # Funções que injetam variáveis em todos os contextos de template.
    @app.context_processor
    def inject_now():
         return {'now': datetime.datetime.utcnow}

    # ### ROTAS DIRETAS (Se não estiverem em blueprints, ou se forem rotas globais como a raiz) ###
    # Se a rota '/' estiver em um blueprint 'main', remova este bloco.
    @app.route('/')
    def index():
        # Verifica se há uma sessão de participante ativa
        if 'participant_account_id' in session:
            flash('Você já está logado. Insira o código da sala para continuar.', 'info')
            # Redireciona para a rota de entrar na sala do blueprint 'participant'
            # Certifique-se de que 'participant.join_room_route' é o nome correto do endpoint
            return redirect(url_for('participant.join_room_route'))
        # Se não houver sessão de participante, renderiza a página inicial genérica
        return render_template('index.html')

    @app.route('/terms')
    def terms_and_conditions():
       return render_template('terms.html', title='Termos e Condições')

    # Rota de Logout Unificada (para Admin e Participante)
    @app.route('/logout')
    def logout():
        # Verifica se um admin está logado via Flask-Login
        if current_user.is_authenticated:
            logout_user() # Desconecta o admin
            flash('Você (Admin) foi desconectado.', 'info')
            # Redireciona para a página de login do admin (ou outra página apropriada)
            return redirect(url_for('auth.login')) # Ajuste 'auth.login' se o endpoint for diferente

        # Verifica se há uma sessão de participante ativa
        elif 'participant_account_id' in session:
            # Limpa as informações da sessão do participante
            session.pop('participant_account_id', None)
            session.pop('participant_id', None)
            session.pop('participant_name', None)
            session.pop('room_code', None)
            session.pop('room_id', None)

            flash('Sua conta de participante foi desconectada.', 'info')
            # Redireciona para a página inicial ou página de entrada de participante
            return redirect(url_for('index')) # Ajuste 'index' ou 'participant.join_room_route' conforme necessário

        # Se não houver sessão de admin ou participante, informa que já está desconectado
        flash('Você já está desconectado.', 'info')
        return redirect(url_for('index'))


    # ### LÓGICA DE INICIALIZAÇÃO NO CONTEXTO DA APP (PODE FICAR, MAS SEM CONSULTAS PREMATURAS) ###
    # Este bloco garante que certas operações que precisam do contexto da aplicação
    # sejam executadas durante a criação da app.
    with app.app_context():
        # Exemplo: Criar tabelas se não existirem (geralmente feito com Flask-Migrate)
        # db.create_all() # Descomente APENAS para testes iniciais sem migrações

        # Remova qualquer lógica que consulte o DB aqui se ela estiver causando o erro inicial
        pass


    # A função factory retorna a instância 'app' configurada
    return app

# ### CRIAÇÃO DA INSTÂNCIA GLOBAL DA APP ###
# Esta linha CRIA a instância 'app' chamando a função factory create_app().
# É esta instância que será usada pelo servidor web (como Gunicorn no PythonAnywhere).
app = create_app()

# ### COMANDO CLI CUSTOMIZADO PARA CRIAR ADMIN ###
# Este bloco DEVE FICAR AQUI, DEPOIS da linha 'app = create_app()',
# para que o comando seja registrado na instância 'app' correta.
# Importe generate_password_hash AQUI dentro da função do comando,
# ou no topo do arquivo se for usado em outro local da aplicação.
from werkzeug.security import generate_password_hash
from models import Admin # Importe o modelo Admin aqui para o comando CLI

@app.cli.command("create-initial-admin")
def create_initial_admin_command():
    """Cria um administrador inicial se nenhum existir."""
    # O contexto da aplicação é necessário para operações de DB
    with app.app_context():
        if Admin.query.first() is None:
            print("Nenhum administrador encontrado.")

            # Define credenciais padrão a partir de variáveis de ambiente ou valores fixos
            default_admin_username = os.environ.get('DEFAULT_ADMIN_USERNAME', 'Admin') #<<<<<< Mudar isso
            default_admin_password = os.environ.get('DEFAULT_ADMIN_PASSWORD', 'Pass123') #<<<<<< Mudar isso

            print(f"Criando administrador padrão: {default_admin_username}")

            # Cria o novo objeto Admin
            initial_admin = Admin(username=default_admin_username)
            # Define a senha usando a função set_password do modelo Admin
            initial_admin.set_password(default_admin_password)

            # Adiciona e salva no banco de dados
            db.session.add(initial_admin)
            db.session.commit()
            print("Administrador padrão criado com sucesso!")
            print("!!! Por favor, mude a senha IMEDIATAMENTE após o primeiro login. !!!")
        else:
            print("Administrador já existe.")
# ### FIM COMANDO CLI CUSTOMIZADO ###


# ### BLOCO PARA RODAR DIRETAMENTE (Opcional com 'python app.py') ###
# Este bloco só é executado se você rodar o arquivo diretamente (python app.py).
# Geralmente não é usado em produção com servidores WSGI como Gunicorn.
# if __name__ == '__main__':
#     app.run(debug=True)
