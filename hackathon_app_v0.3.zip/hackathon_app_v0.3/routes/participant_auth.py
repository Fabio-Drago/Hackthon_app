# routes/participant_auth.py
from flask import Blueprint, render_template, redirect, url_for, flash, request, session
# Importe o novo modelo ParticipantAccount
from models import db, ParticipantAccount
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, Length, EqualTo, ValidationError
from werkzeug.security import generate_password_hash, check_password_hash # Já importado em models, mas útil aqui também

participant_auth_bp = Blueprint('participant_auth', __name__)

# --- Formulários WTForms para Registro e Login de Participante ---

# Formulário de Registro para Participante
class ParticipantRegistrationForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email(), Length(max=120)])
    password = PasswordField('Senha', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirmar Senha', validators=[DataRequired(), EqualTo('password', message='As senhas devem ser iguais.')])
    submit = SubmitField('Registrar')

    # Validação customizada para verificar se o email já existe
    def validate_email(self, email):
        account = ParticipantAccount.query.filter_by(email=email.data).first()
        if account:
            raise ValidationError('Este email já está registrado. Por favor, use um email diferente ou faça login.')

# Formulário de Login para Participante
class ParticipantLoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Senha', validators=[DataRequired()])
    submit = SubmitField('Entrar')


# --- Rotas de Autenticação do Participante ---

@participant_auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    # Se um participante já estiver logado (conta na sessão), redireciona para a entrada da sala
    if 'participant_account_id' in session:
        flash('Você já possui uma conta logada.', 'info')
        return redirect(url_for('participant.join_room_route')) # Redireciona para a entrada da sala

    form = ParticipantRegistrationForm() # Cria uma instância do formulário de registro

    if form.validate_on_submit(): # Processa o formulário se for POST e válido
        # Cria uma nova conta de participante com os dados do formulário
        new_account = ParticipantAccount(email=form.email.data)
        new_account.set_password(form.password.data) # Salva a senha hasheada

        try:
            db.session.add(new_account) # Adiciona a nova conta à sessão do DB
            db.session.commit() # Salva as mudanças no DB
            flash('Sua conta foi criada com sucesso! Agora faça login.', 'success') # Mensagem de sucesso
            # Redireciona para a página de login de participante
            return redirect(url_for('participant_auth.login'))
        except Exception as e:
             db.session.rollback()
             flash(f'Erro ao registrar conta: {e}', 'danger') # Mensagem de erro

    # Renderiza o template de registro, passando o formulário
    return render_template('participant_auth/register.html', title='Criar Conta Participante', form=form)


@participant_auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    # Se um participante já estiver logado (conta na sessão), redireciona para a entrada da sala
    if 'participant_account_id' in session:
        flash('Você já possui uma conta logada.', 'info')
        return redirect(url_for('participant.join_room_route')) # Redireciona para a entrada da sala

    form = ParticipantLoginForm() # Cria uma instância do formulário de login

    if form.validate_on_submit(): # Processa o formulário se for POST e válido
        # Busca a conta de participante pelo email
        account = ParticipantAccount.query.filter_by(email=form.email.data).first()

        # Verifica se a conta existe e se a senha está correta
        if account and account.check_password(form.password.data):
            # Autenticação bem-sucedida! Armazena o ID da conta na sessão
            session['participant_account_id'] = account.id
            # Opcional: Armazenar o email na sessão também, mas cuidado com dados sensíveis
            # session['participant_account_email'] = account.email
            flash('Login de participante bem-sucedido!', 'success') # Mensagem de sucesso
            # Redireciona para a página de entrada da sala (onde o código será inserido)
            return redirect(url_for('participant.join_room_route'))
        else:
            # Login falhou
            flash('Email ou senha inválidos.', 'danger')

    # Renderiza o template de login, passando o formulário
    return render_template('participant_auth/login.html', title='Login Participante', form=form)