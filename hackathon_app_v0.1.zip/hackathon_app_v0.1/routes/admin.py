# routes/admin.py
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from models import db, Room, Question
from utils.code_gen import generate_room_code
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField, HiddenField
from wtforms.validators import DataRequired, Length

admin_bp = Blueprint('admin', __name__)

# --- Formulários WTForms ---
class RoomForm(FlaskForm):
    name = StringField('Nome da Sala', validators=[DataRequired(), Length(min=3, max=100)])
    submit = SubmitField('Criar Sala')

class QuestionForm(FlaskForm):
    text = TextAreaField('Texto da Pergunta', validators=[DataRequired()])
    room_id = HiddenField() # Para associar a pergunta à sala correta
    submit = SubmitField('Adicionar Pergunta')

# --- Rotas ---
@admin_bp.route('/dashboard')
@login_required
def dashboard():
    rooms = Room.query.order_by(Room.created_at.desc()).all()
    return render_template('admin/dashboard.html', title='Dashboard Admin', rooms=rooms)

@admin_bp.route('/create_room', methods=['GET', 'POST'])
@login_required
def create_room():
    form = RoomForm()
    if form.validate_on_submit():
        new_code = generate_room_code()
        new_room = Room(name=form.name.data, code=new_code)
        # Se você tiver a relação com admin: new_room.admin_id = current_user.id
        db.session.add(new_room)
        db.session.commit()
        flash(f'Sala "{new_room.name}" criada com o código {new_room.code}!', 'success')
        return redirect(url_for('admin.dashboard'))
    return render_template('admin/create_room.html', title='Criar Nova Sala', form=form)

@admin_bp.route('/room/<int:room_id>/manage', methods=['GET', 'POST'])
@login_required
def room_management(room_id):
    room = Room.query.get_or_404(room_id)
    question_form = QuestionForm(room_id=room_id) # Passa o room_id para o campo hidden

     # Se o formulário de pergunta for submetido via POST e for válido
    if request.method == 'POST' and question_form.validate_on_submit():
        new_question = Question(text=question_form.text.data, room_id=room.id)
        db.session.add(new_question)
        db.session.commit()
        flash('Pergunta adicionada com sucesso!', 'success')
        # Redireciona para a mesma página de gerenciamento para evitar reenvio do formulário
        return redirect(url_for('admin.room_management', room_id=room_id))

    # Carrega as perguntas associadas a esta sala
    questions = Question.query.filter_by(room_id=room.id).order_by(Question.id).all()

    return render_template('admin/room_management.html', title=f'Gerenciar Sala: {room.name}',
                           room=room, questions=questions, question_form=question_form)

@admin_bp.route('/room/<int:room_id>/toggle_active', methods=['POST'])
@login_required
def toggle_room_active(room_id):
    room = Room.query.get_or_404(room_id)
    room.is_active = not room.is_active
    db.session.commit()
    status = "ativada" if room.is_active else "desativada"
    flash(f'Sala "{room.name}" foi {status}.', 'info')
    # Tenta redirecionar de volta para onde o admin estava (dashboard ou manage)
    referer = request.headers.get("Referer")
    if referer and 'manage' in referer:
         return redirect(url_for('admin.room_management', room_id=room_id))
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/room/<int:room_id>/delete', methods=['POST'])
@login_required
def delete_room(room_id):
    room = Room.query.get_or_404(room_id)
    # O cascade="all, delete-orphan" nos relacionamentos deve cuidar de
    # deletar perguntas e respostas associadas. Teste isso!
    # Participantes não são deletados automaticamente aqui, talvez você queira.
    try:
        db.session.delete(room)
        db.session.commit()
        flash(f'Sala "{room.name}" e suas perguntas/respostas foram deletadas.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao deletar sala: {e}', 'danger')
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/question/<int:question_id>/delete', methods=['POST'])
@login_required
def delete_question(question_id):
    question = Question.query.get_or_404(question_id)
    room_id = question.room_id # Guarda o ID da sala para redirecionar
    try:
        db.session.delete(question)
        db.session.commit()
        flash('Pergunta deletada com sucesso.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao deletar pergunta: {e}', 'danger')
    return redirect(url_for('admin.room_management', room_id=room_id))

# Adicionar rotas para visualizar participantes e respostas (Opcional Avançado)
# @admin_bp.route('/room/<int:room_id>/results')
# @login_required
# def view_results(room_id):
#    room = Room.query.get_or_404(room_id)
#    # Lógica para buscar participantes e suas respostas para esta sala
#    return render_template('admin/view_results.html', room=room, ...)