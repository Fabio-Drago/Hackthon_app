# models.py
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
import datetime # Para timestamps, se necessário

# Instância do SQLAlchemy (será inicializada no app.py)
db = SQLAlchemy()

# Modelo para Administradores (usando Flask-Login)
class Admin(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(256)) # Aumentado tamanho para hashes mais longos

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f'<Admin {self.username}>'

# Modelo para Salas
class Room(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    code = db.Column(db.String(6), unique=True, nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    # Relação com Admin (opcional, se quiser saber quem criou)
    # admin_id = db.Column(db.Integer, db.ForeignKey('admin.id'))
    # admin = db.relationship('Admin', backref=db.backref('rooms', lazy=True))

    # Relação com Perguntas
    questions = db.relationship('Question', backref='room', lazy='dynamic', cascade="all, delete-orphan")
    # Relação com Participantes que entraram na sala
    participants = db.relationship('Participant', backref='room', lazy='dynamic')

    def __repr__(self):
        return f'<Room {self.name} ({self.code})>'

# Modelo para Perguntas
class Question(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.Text, nullable=False)
    room_id = db.Column(db.Integer, db.ForeignKey('room.id'), nullable=False)
    # Relação com Respostas
    answers = db.relationship('Answer', backref='question', lazy='dynamic', cascade="all, delete-orphan")

    def __repr__(self):
        return f'<Question {self.id} for Room {self.room_id}>'

# Modelo para Participantes (quem entrou na sala)
class Participant(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    room_id = db.Column(db.Integer, db.ForeignKey('room.id'), nullable=False)
    joined_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    # Relação com Respostas
    answers = db.relationship('Answer', backref='participant', lazy='dynamic')

    def __repr__(self):
        return f'<Participant {self.name} in Room {self.room_id}>'

# Modelo para Respostas
class Answer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.Text, nullable=False)
    submitted_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    participant_id = db.Column(db.Integer, db.ForeignKey('participant.id'), nullable=False)
    question_id = db.Column(db.Integer, db.ForeignKey('question.id'), nullable=False)

    def __repr__(self):
        return f'<Answer by Participant {self.participant_id} for Question {self.question_id}>'