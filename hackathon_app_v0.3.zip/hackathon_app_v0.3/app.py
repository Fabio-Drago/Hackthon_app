# app.py
import datetime
# Importe session, logout_user, current_user para a rota logout genérica
from flask import Flask, render_template, redirect, url_for, flash, request, session
from config import Config
# Importe os modelos necessários
from models import db, Admin, ParticipantAccount # Importe ParticipantAccount
from flask_login import LoginManager, logout_user, current_user
from flask_migrate import Migrate
import os

# Criação da instância do LoginManager (para Admin)
login_manager = LoginManager()
login_manager.login_view = 'auth.login' # Rota para onde redirecionar admin se não estiver logado
login_manager.login_message = 'Por favor, faça login (admin) para acessar esta página.'
login_manager.login_message_category = 'info'

migrate = Migrate()

# Função para carregar o usuário Admin (necessária para Flask-Login)
@login_manager.user_loader
def load_user(user_id):
    # Retorna um objeto Admin ou None
    return Admin.query.get(int(user_id))

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)

    @app.context_processor
    def inject_now():
        return {'now': datetime.datetime.utcnow}

    # Registrar Blueprints
    from routes.auth import auth_bp # Admin Auth
    from routes.admin import admin_bp # Admin
    from routes.participant import participant_bp # Participant (Join Room, Questions)
    # ### Registrar o novo Blueprint de Autenticação do Participante ###
    from routes.participant_auth import participant_auth_bp # Participant Auth
    # ### Fim do Registro ###


    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(admin_bp, url_prefix='/admin')
    app.register_blueprint(participant_bp, url_prefix='/') # Rotas de participante na raiz
    # ### Registrar o novo Blueprint com prefixo /participant ###
    app.register_blueprint(participant_auth_bp, url_prefix='/participant') # Rotas de autenticação participante
    # ### Fim do Registro ###


    @app.route('/')
    def index():
        # ### Nova Lógica: Redirecionar Participante Logado (conta) para a entrada da sala ###
        # Verifica se o ID da conta do participante está na sessão
        if 'participant_account_id' in session:
             # Se sim, redireciona para a página onde ele insere o código da sala
             flash('Você já está logado. Insira o código da sala para continuar.', 'info')
             return redirect(url_for('participant.join_room_route'))
        # ### Fim da Nova Lógica ###

        # Se não houver conta de participante logada, renderiza a página inicial normal
        return render_template('index.html')

    @app.route('/terms')
    def terms_and_conditions():
       return render_template('terms.html', title='Termos e Condições')

    # ROTA DE LOGOUT GENÉRICA (agora lida com Admin ou Participante)
    @app.route('/logout')
    def logout():
        # Verifica se um admin está logado via Flask-Login
        if current_user.is_authenticated:
            logout_user() # Faz logout do admin
            flash('Você (Admin) foi desconectado.', 'info')
            return redirect(url_for('auth.login')) # Redireciona para o login admin

        # Verifica se um participante está "logado" via sessão (verificando o ID da conta)
        elif 'participant_account_id' in session:
            # Remove as informações da conta do participante da sessão
            session.pop('participant_account_id', None)
            # Opcional: Remover outras chaves de participante se existirem (como name, room_id, etc.)
            session.pop('participant_id', None) # A entrada Participant específica da sala
            session.pop('participant_name', None) # O nome usado naquela entrada
            session.pop('room_code', None)
            session.pop('room_id', None)

            flash('Sua conta de participante foi desconectada.', 'info')
            return redirect(url_for('index')) # Redireciona para a página inicial

        # Se ninguém estava logado, apenas redireciona para a página inicial
        flash('Você já está desconectado.', 'info')
        return redirect(url_for('index'))


    with app.app_context():
        # As tabelas agora são criadas via Flask-Migrate.
        # Mantenha este bloco para o context_processor ou outras inicializações.
        pass # Remova db.create_all() se estiver usando Flask-Migrate

    ### MUITO IMPORTANTE!!!! ISSO SERVE PARA CRIAR UM ADMIN INICIAL (Adicione como comentários depois de criar!) ###
        # Verifica se já existe algum administrador no banco de dados
        #if Admin.query.first() is None:
            # Define um nome de usuário e senha padrão para o primeiro admin
            # ALTAMENTE RECOMENDADO: MUDAR ESTAS CREDENCIAIS APÓS O PRIMEIRO LOGIN!
            #default_admin_username = os.environ.get('DEFAULT_ADMIN_USERNAME', 'RedPrince') # <<< MUDAR ISSO!
            #default_admin_password = os.environ.get('DEFAULT_ADMIN_PASSWORD', 'Angola123') # <<< MUDAR ISSO!

            # Cria o objeto Admin e define a senha (que será hasheada internamente)
            #initial_admin = Admin(username=default_admin_username)
            #initial_admin.set_password(default_admin_password)

            # Adiciona o admin à sessão do banco de dados e salva
            #db.session.add(initial_admin)
            #db.session.commit()
            #print(f"Admin padrão '{default_admin_username}' criado. Por favor, mude a senha após o login.")
        ### FIM DO SNIPPET PARA CRIAR ADMIN INICIAL ###

    return app

app = create_app()

if __name__ == '__main__':
    app.run(debug=True)