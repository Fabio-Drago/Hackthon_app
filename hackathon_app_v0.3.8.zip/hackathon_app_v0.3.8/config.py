# config.py
import os
from dotenv import load_dotenv

# Carrega variáveis do arquivo .env
basedir = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(basedir, '.env'))

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'fallback-secret-key-if-not-set' # << TROQUE NO .env >>
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///' + os.path.join(basedir, 'app.db') # Fallback para SQLite se DB_URL não estiver no .env
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # Outras configurações podem ser adicionadas aqui