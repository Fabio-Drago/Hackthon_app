# app.py
import datetime
from flask import Flask, render_template
from config import Config
from models import db, Admin # Importe Admin para o user_loader
from flask_login import LoginManager
import os

# Criação da instância do LoginManager
login_manager = LoginManager()
login_manager.login_view = 'auth.login' # Rota para onde redirecionar se não estiver logado
login_manager.login_message = 'Por favor, faça login para acessar esta página.'
login_manager.login_message_category = 'info' # Categoria da mensagem flash

# Função para carregar o usuário (necessária para Flask-Login)
@login_manager.user_loader
def load_user(user_id):
    return Admin.query.get(int(user_id))

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Inicializa as extensões com a app
    db.init_app(app)
    login_manager.init_app(app)

    @app.context_processor
    def inject_now():
        """Injects the current UTC datetime into the template context."""
        # Usamos utcnow() que é geralmente preferível em backends
        # a menos que você precise especificamente do fuso horário do servidor.
        return {'now': datetime.datetime.utcnow}

    # Registrar Blueprints (rotas)
    from routes.auth import auth_bp
    from routes.admin import admin_bp
    from routes.participant import participant_bp

    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(admin_bp, url_prefix='/admin')
    app.register_blueprint(participant_bp, url_prefix='/') # Rotas de participante na raiz

    # Rota inicial simples (pode redirecionar ou ser a página de join)
    @app.route('/')
    def index():
        # Pode redirecionar para a página de join do participante
        # return redirect(url_for('participant.join_room_route'))
        # Ou renderizar uma página inicial simples
        return render_template('index.html')

    # Criar tabelas do banco de dados (executar uma vez ou usar Flask-Migrate)
    with app.app_context():
        # Comentar após a primeira execução ou usar Flask-Migrate
        # db.create_all()
        print("Verifique se as tabelas foram criadas no banco de dados 'Hackton'.")
        # Você pode criar um admin inicial aqui, se necessário!
        # if not Admin.query.filter_by(username='admin').first():
            # print("Criando usuário admin padrão...")
             # admin_user = Admin(username='admin')
             # admin_user.set_password('admin123') # Troque por uma senha forte
             # db.session.add(admin_user)
             # db.session.commit()
             # print("Usuário admin criado com senha 'admin123'. Troque-a!")

    return app

# Cria a aplicação
app = create_app()

# Bloco para rodar o servidor de desenvolvimento
if __name__ == '__main__':
    # Pegar host e porta das configurações (se definidas) ou usar padrão
    # host = os.environ.get('HOSTNAME', '127.0.0.1')
    # port = int(os.environ.get('PORT', 5000)) # Flask default é 5000
    # app.run(host=host, port=port, debug=True) # debug=True é útil em desenvolvimento
    app.run(debug=True) # Roda em http://127.0.0.1:5000 por padrão