# routes/admin.py
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user # Importe current_user
# Importe todos os modelos necessários
from models import db, Room, Question, Participant, Answer, Admin, ParticipantAccount
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField, HiddenField
from wtforms.validators import DataRequired, Length, Regexp
import random
import string
from datetime import datetime # Importe datetime se ainda não importou

admin_bp = Blueprint('admin', __name__)

# --- Formulários WTForms ---
class RoomForm(FlaskForm):
    name = StringField('Nome da Sala', validators=[DataRequired(), Length(min=3, max=100)])
    submit = SubmitField('Criar Sala')

class QuestionForm(FlaskForm):
    text = TextAreaField('Texto da Pergunta', validators=[DataRequired()])
    room_id = HiddenField() # Para associar a pergunta à sala correta
    submit = SubmitField('Adicionar Pergunta')

# --- Rotas da Área Administrativa ---

@admin_bp.route('/dashboard')
@login_required # Restringe o acesso a usuários logados (Admins)
def dashboard():
    # Busca todas as salas ordenadas pela data de criação (mais recente primeiro)
    rooms = Room.query.order_by(Room.created_at.desc()).all()
    # Renderiza o template do dashboard, passando a lista de salas
    return render_template('admin/dashboard.html', title='Dashboard Admin', rooms=rooms)

def generate_unique_room_code(): # <-- VERIFIQUE O NOME EXATO AQUI
    # Generate a 6-character code using uppercase letters and digits
    while True:
        code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        # Check if a room with this code already exists
        existing_room = Room.query.filter_by(code=code).first()
        if not existing_room:
            return code

# Rota para Criar Sala - CORRIGIDA (Verifique cuidadosamente!)
@admin_bp.route('/create_room', methods=['GET', 'POST'])
@login_required # Garante que um admin está logado
def create_room():
    form = RoomForm()
    if form.validate_on_submit():
        room_name = form.name.data
        # Gerar um código de sala único
        room_code = generate_unique_room_code()

        # Cria o novo objeto Sala
        new_room = Room(name=room_name, code=room_code)

        # ### VERIFIQUE ESTA LINHA E SUA INDENTAÇÃO ###
        new_room.admin_id = current_user.id # <-- Esta linha deve estar aqui e bem indentada
        # ### Fim da VERIFICAÇÃO ###

        db.session.add(new_room)

        # ### Bloco try...except para o commit ###
        try:
            db.session.commit() # Tenta salvar as mudanças no DB
            flash('Sala criada com sucesso!', 'success')
            return redirect(url_for('admin.dashboard'))
        except Exception as e:
            db.session.rollback() # Desfaz a transação em caso de erro
            flash(f'Erro ao criar sala: {e}', 'danger')
            # Opcional: Logar o erro completo do traceback para depuração mais detalhada
            # app.logger.error(f'Erro ao criar sala: {e}', exc_info=True)
        # ### Fim do bloco try...except ###

    return render_template('admin/create_room.html', title='Criar Nova Sala', form=form)

@admin_bp.route('/room/<int:room_id>/manage', methods=['GET', 'POST'])
@login_required # Restringe o acesso a usuários logados (Admins)
def room_management(room_id):
    # Busca a sala pelo ID ou retorna 404 se não encontrar
    room = Room.query.get_or_404(room_id)
    # Cria uma instância do formulário de pergunta, passando o ID da sala para o campo oculto
    question_form = QuestionForm(room_id=room_id)

    # Processa o formulário de pergunta se for POST e válido
    # Verificamos o método e a validação on_submit
    if request.method == 'POST' and question_form.validate_on_submit():
         new_question = Question(text=question_form.text.data, room_id=room.id) # Cria um novo objeto Question
         db.session.add(new_question) # Adiciona a nova pergunta à sessão do DB
         db.session.commit() # Salva as mudanças no DB
         flash('Pergunta adicionada com sucesso!', 'success') # Mensagem de sucesso
         # Redireciona para a mesma página de gerenciamento para evitar reenvio do formulário
         return redirect(url_for('admin.room_management', room_id=room_id))

    # Carrega as perguntas associadas a esta sala, ordenadas por ID
    questions = Question.query.filter_by(room_id=room.id).order_by(Question.id).all()

    # Renderiza o template de gerenciamento de sala, passando os dados
    return render_template('admin/room_management.html',
                           title=f'Gerenciar Sala: {room.name}',
                           room=room,
                           questions=questions,
                           question_form=question_form) # Passa o formulário para o template

@admin_bp.route('/room/<int:room_id>/toggle_active', methods=['POST'])
@login_required # Restringe o acesso a usuários logados (Admins)
def toggle_room_active(room_id):
    room = Room.query.get_or_404(room_id) # Busca a sala
    room.is_active = not room.is_active # Inverte o status de ativo
    db.session.commit() # Salva a mudança no DB
    status = "ativada" if room.is_active else "desativada"
    flash(f'Sala "{room.name}" foi {status}.', 'info') # Mensagem informativa
    # Tenta redirecionar de volta para onde o admin estava (dashboard ou manage)
    referer = request.headers.get("Referer")
    if referer: # Verifica se há um Referer e se contém 'manage' ou 'dashboard'
         if 'manage' in referer:
             return redirect(url_for('admin.room_management', room_id=room_id))
         elif 'dashboard' in referer:
             return redirect(url_for('admin.dashboard'))
    # Redireciona para o dashboard como fallback
    return redirect(url_for('admin.dashboard'))


@admin_bp.route('/room/<int:room_id>/delete', methods=['POST'])
@login_required # Restringe o acesso a usuários logados (Admins)
def delete_room(room_id):
    room = Room.query.get_or_404(room_id) # Busca a sala
    # O cascade="all, delete-orphan" na relação Room.participants e Room.questions
    # garante que os participantes e perguntas associados (e as respostas deles)
    # sejam deletados automaticamente quando a sala é deletada.
    try:
        db.session.delete(room) # Deleta a sala da sessão do DB
        db.session.commit() # Salva as mudanças no DB
        flash(f'Sala "{room.name}" e seus dados associados foram deletados.', 'success') # Mensagem de sucesso
    except Exception as e:
        db.session.rollback() # Reverte a operação em caso de erro
        flash(f'Erro ao deletar sala: {e}', 'danger') # Mensagem de erro
    return redirect(url_for('admin.dashboard')) # Redireciona para o dashboard

@admin_bp.route('/question/<int:question_id>/delete', methods=['POST'])
@login_required # Restringe o acesso a usuários logados (Admins)
def delete_question(question_id):
    question = Question.query.get_or_404(question_id) # Busca a pergunta
    room_id = question.room_id # Guarda o ID da sala para redirecionar de volta
    try:
        db.session.delete(question) # Deleta a pergunta da sessão do DB
        db.session.commit() # Salva as mudanças no DB
        flash('Pergunta deletada com sucesso.', 'success') # Mensagem de sucesso
    except Exception as e:
        db.session.rollback() # Reverte a operação em caso de erro
        flash(f'Erro ao deletar pergunta: {e}', 'danger') # Mensagem de erro
    # Redireciona de volta para a página de gerenciamento da sala de onde veio
    return redirect(url_for('admin.room_management', room_id=room_id))


# Rota para Exibir Resultados - COM FILTROS
@admin_bp.route('/room/<int:room_id>/results')
@login_required
def view_results(room_id):
    room = Room.query.get_or_404(room_id)

    # Verifica se o admin logado é o criador da sala (opcional, se reativado)
    # if room.admin_id != current_user.id:
    #     flash('Você não tem permissão para ver os resultados desta sala.', 'danger')
    #     return redirect(url_for('admin.dashboard'))

    # ### Lógica para obter parâmetros de filtro da URL ###
    filter_email = request.args.get('email') # Obtém o parâmetro 'email' da URL
    filter_participant_id = request.args.get('participant_entry_id') # Obtém o parâmetro 'participant_entry_id' da URL
    # ### Fim da Lógica de Filtro ###


    # ### Lógica para construir a query com filtros ###

    # Query base para participantes na sala
    participants_in_room_query = Participant.query.filter_by(room_id=room.id)

    # Aplica filtro por email, se fornecido
    if filter_email:
        # Busca as ParticipantAccounts com o email fornecido
        accounts_with_email = ParticipantAccount.query.filter_by(email=filter_email).all()
        # Pega os IDs dessas contas
        account_ids = [account.id for account in accounts_with_email]
        # Filtra os participantes cujos account_id estão na lista
        participants_in_room_query = participants_in_room_query.filter(Participant.account_id.in_(account_ids))

    # Aplica filtro por participant_entry_id, se fornecido
    if filter_participant_id:
        try:
            # Converte o ID para inteiro
            participant_entry_id_int = int(filter_participant_id)
            # Filtra os participantes pelo ID da entrada
            participants_in_room_query = participants_in_room_query.filter_by(id=participant_entry_id_int)
        except ValueError:
            # Se o ID não for um número válido, exibe um erro e não aplica o filtro
            flash('ID de participante inválido.', 'warning')


    # Executa a query filtrada para obter as entradas de participante
    participants_in_room = participants_in_room_query.all()

    # ### Fim da Lógica de Query com Filtros ###


    # Lista para armazenar os resultados formatados para o template
    results_list = []

    # Itera sobre cada entrada de participante que passou pelos filtros
    for participant_entry in participants_in_room:
        # Busca o ParticipantAccount associado a esta entrada
        participant_account = ParticipantAccount.query.get(participant_entry.account_id)

        # Busca todas as respostas submetidas por ESTA ENTRADA de participante (participant_entry.id)
        answers_for_entry = Answer.query.filter_by(participant_id=participant_entry.id).order_by(Answer.submitted_at).all()

        # Adiciona os dados desta entrada (incluindo o email da conta e suas respostas) à lista de resultados
        results_list.append({
            'participant_entry_id': participant_entry.id,
            'participant_email': participant_account.email if participant_account else 'Conta Desconhecida',
            'answers': answers_for_entry
        })

    # Passa a lista de resultados e os valores de filtro atuais para o template
    return render_template('admin/view_results.html',
                           title=f'Resultados da Sala: {room.name}',
                           room=room,
                           results=results_list,
                           filter_email=filter_email, # Passa o email filtrado para preencher o formulário
                           filter_participant_id=filter_participant_id) # Passa o ID filtrado para preencher o formulário